<?php
if(!defined('C_CNFLY')) {
	exit();
}

?>