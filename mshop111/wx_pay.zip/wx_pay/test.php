<?php

$arrwpay = laimi_config_wpay();
var_dump($arrwpay);